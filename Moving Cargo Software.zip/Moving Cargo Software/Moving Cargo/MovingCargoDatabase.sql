

CREATE DATABASE MovingCargoDatabase
CREATE TABLE Users
(
UserID INT IDENTITY(1000,2) NOT NULL,
Username VARCHAR(30) NOT NULL,
UserPassword VARCHAR(30) NOT NULL,
Name VARCHAR (30) NOT NULL,
Surname VARCHAR(30) NOT NULL,
Email_Address VARCHAR(30) NOT NULL,
Contact_Number CHAR(10) NOT NULL,
User_Type VARCHAR(12) NOT NULL,
CONSTRAINT PK_User_ID PRIMARY KEY (UserID)
);

---Customer Table
CREATE TABLE Customers(
Customer_ID CHAR (13) NOT NULL,
Customer_Name VARCHAR (30) NOT NULL,
Customer_Surname VARCHAR(30) NOT NULL,
Customer_Cell_Num CHAR (10)NOT NULL,
Customer_Email VARCHAR(30)NOT NULL,
House_Num INT NOT NULL,
Street_Name VARCHAR(30) NOT NULL,
Suburb VARCHAR(30) NOT NULL,
ZipCode VARCHAR(10) NOT NULL,
CONSTRAINT PK_Customer PRIMARY KEY (Customer_ID)
);


 ---Booking Table
 CREATE TABLE Booking_Trip (
 Booking_Num INT IDENTITY(100,2),
 Driver_Num INT NOT NULL,
 Customer_ID CHAR (13) NOT NULL,
 Booking_Price DECIMAL NOT NULL,
 Trip_Num CHAR(5) NOT NULL, 
 Cargo VARCHAR (20) NOT NULL,
 Confirmation_Order BIT NOT NULL,
 Date_Ordered DATE NOT NULL,
 Zip_Code VARCHAR (10) NOT NULL,
 Street_Name VARCHAR(30) NOT NULL,
 Suburb VARCHAR(30) NOT NULL,
 Approval BIT NOT NULL,
 CONSTRAINT PK_Booking_Trip PRIMARY KEY (Booking_Num),
 CONSTRAINT FK_Cus_Booking_Trip FOREIGN KEY(Customer_ID) REFERENCES Customers(Customer_ID),
 CONSTRAINT FK_Driver_Num FOREIGN KEY (Driver_Num) REFERENCES Driver(Driver_Num), 
 CONSTRAINT FK_Trip_Num FOREIGN KEY (Trip_Num) REFERENCES Trips(Trip_Num));
 

---Driver Table
CREATE TABLE Driver(
Driver_Num INT IDENTITY (100,1),
Driver_Name VARCHAR(30)NOT NULL,
Driver_Surname VARCHAR(30)NOT NULL,
Driver_DOB DATE NOT NULL,
Driver_ID CHAR(13) NOT NULL,
Driver_Email VARCHAR(30) NOT NULL,
Driver_Cell CHAR (10) NOT NULL,
Street_Name VARCHAR (30) NOT NULL,
House_Num INT NOT NULL,
Suburb VARCHAR(30) NOT NULL,
ZipCode VARCHAR(10) NOT NULL,
CONSTRAINT PK_Driver PRIMARY KEY (Driver_Num));

---Employee Table 
CREATE TABLE Employee(
Employee_ID CHAR(13) NOT NULL,
Employee_Name VARCHAR(30) NOT NULL,
Employee_Surname VARCHAR (30) NOT NULL,
Date_Of_Birth DATE NOT NULL,
Job_Position VARCHAR (50) NOT NULL,
Employee_Shift_Hours DECIMAL NOT NULL,
Employee_Email VARCHAR (30) NOT NULL,
Employee_Cell_Num CHAR (10) NOT NULL,
House_Num INT NOT NULL,
Street_Name VARCHAR (30) NOT NULL,
Suburb VARCHAR (30) NOT NULL,
Zip_Code VARCHAR (12) NOT NULL,
CONSTRAINT PK_Employee PRIMARY KEY (Employee_ID)			
);

---Trip Table
CREATE TABLE Trips(
Trip_Num CHAR(5) NOT NULL,--
Employee_ID CHAR(13) NOT NULL,--
Vehicle_Num CHAR (4) NOT NULL,--
Customer_ID CHAR (13) NOT NULL,--
Driver_Num INT NOT NULL,--
Trip_Schedule DATE NOT NULL,
Distance DECIMAL NOT NULL,
Trip_Status VARCHAR (30) NOT NULL,
CONSTRAINT PK_Trips PRIMARY KEY (Trip_Num),
CONSTRAINT FK_Emp_Trip FOREIGN KEY(Employee_ID) REFERENCES Employee(Employee_ID),
CONSTRAINT FK_Customer_Trip FOREIGN KEY(Customer_ID) REFERENCES Customers(Customer_ID),
CONSTRAINT FK_Vehicle_Trip FOREIGN KEY(Vehicle_Num) REFERENCES Vehicle_Info(Vehicle_Num), 
Constraint FK_Driver FOREIGN KEY (Driver_Num) REFERENCES Driver(Driver_Num));


---Service Appointment
CREATE TABLE Service_Appointment(
Service_Num VARCHAR (10) NOT NULL,
Appointment_Num CHAR (5) NOT NULL,-- This should be auto-generated
Vehicle_Num CHAR (4) NOT NULL,
Service_Description VARCHAR (60) NOT NULL,
Vehicle_Description VARCHAR (50) NOT NULL,
CONSTRAINT PK_Appointment PRIMARY KEY (Appointment_Num),
CONSTRAINT FK_Service_appointment FOREIGN KEY(Vehicle_Num) REFERENCES Vehicle_Info(Vehicle_Num));

--Vehicle Information Table
CREATE TABLE Vehicle_Info(
Vehicle_Num CHAR(4) NOT NULL,
Reg_Num CHAR(8) NOT NULL,--eRROR
Vehicle_Type VARCHAR(40) NOT NULL,
Manufacturer VARCHAR(40) NOT NULL,
Engine_Size VARCHAR(20) NOT NULL,
Current_Odometer VARCHAR(10) NOT NULL,
Next_Service VARCHAR(10) NOT NULL,
Num_Trips INT NOT NULL,
Avail_Trips BIT NOT NULL,
CONSTRAINT PK_Vehicle_Info PRIMARY KEY (Vehicle_Num));
--Please note you ended here

CREATE TABLE Timesheet 
(
Timesheet_ID INT IDENTITY (100,1),
Employee_ID CHAR(13) NOT NULL, 
Hours_Worked INT NOT NULL,
Time_In VARCHAR(30) NOT NULL, 
Time_Out VARCHAR(30) NOT NULL,
CONSTRAINT PK_Timesheet_ID PRIMARY KEY (Timesheet_ID),
CONSTRAINT FK_Employee_ID FOREIGN KEY (Employee_ID) REFERENCES Employee(Employee_ID)
);



SELECT * FROM Users;
SELECT * FROM Customers;
SELECT * FROM Employee;
SELECT * FROM Booking_Trip;
SELECT * FROM Driver;
SELECT * FROM Service_Appointment;
SELECT * FROM Trips;
SELECT * FROM Vehicle_Info;
SELECT * FROM TimeSheet;


