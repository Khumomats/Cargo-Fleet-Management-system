﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Moving_Cargo
{
    public partial class Edit_Driver : Form
    {
        public Edit_Driver()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options p = new Options();
            p.ShowDialog();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "UPDATE Driver SET Driver_Name = '" + txtName.Text + "', Driver_Surname  = '" + txtSurname.Text + "', " +
                                                  "Driver_DOB= '" + dateTimePicker1.Value + "', Driver_ID = '" + txtDriverID.Text + "', Driver_Email = '" + txtEmail.Text + "'," +
                                                  " Driver_Cell= '" + txtCellNumber.Text + "', Street_Name= '" + txtStreetName.Text + "', House_Num= '" + txtHouseNumber.Text + "', Suburb= '" + txtSuburb.Text + "', ZipCode= '" + txtZipCode.Text + "'" +
                                                  "WHERE Driver_Num= '" + cmbDriverNum.Text + "'";
                SqlCommand command = new SqlCommand(sql, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Employee details successfully updated!!!:");

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void cmbDriverNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Driver";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (cmbDriverNum.Text.Equals(reader[0].ToString()))
                    {
                        check = true;
                        txtName.Text = reader[1].ToString();
                        txtSurname.Text = reader[2].ToString();
                        dateTimePicker1.Text = reader[3].ToString();
                        txtDriverID.Text = reader[4].ToString();
                        txtEmail.Text = reader[5].ToString();
                        txtCellNumber.Text = reader[6].ToString();
                        txtStreetName.Text = reader[7].ToString();
                        txtHouseNumber.Text = reader[8].ToString();
                        txtSuburb.Text = reader[9].ToString();
                        txtZipCode.Text = reader[10].ToString();
                        break;
                    }
                    

                }
                if (check == true)
                {
                    MessageBox.Show("You can start editing Driver details \n" + 
                                    " For Name : "+ reader[1].ToString() + "\n" +
                                    " Surname: " + reader[2].ToString());
                }
                else if(check ==false)
                {
                    MessageBox.Show("The Driver ID you chose doesn't match any in the database!!!! ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occured: " + ex.Message);

            }
        }
        private void Edit_Driver_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Driver";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    check = true;
                    cmbDriverNum.Items.Add(reader[0].ToString());
                }
               
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
        }
        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_OnValueChanged(object sender, EventArgs e)
        {

        }

        
    }
}
