﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void btnCustomerSave_Click(object sender, EventArgs e)
        {
            try 
            {
                if (txtEmpID.Text.Length < 13 || txtEmpID.Text.Length > 13)
                {
                    MessageBox.Show("ID number should be 13 digits");

                }
                else if (txtCellNumber.Text.Length < 10 || txtCellNumber.Text.Length > 10)
                {
                    MessageBox.Show("Cell phone number should be 10 digits");

                }
                else 
                {
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "INSERT INTO Employee" +
                                 "(" +
                                 "Employee_ID, Employee_Name, Employee_Surname, Date_Of_Birth,Job_Position, Employee_Shift_Hours, Employee_Email, Employee_Cell_Num, House_Num, Street_Name, Suburb, Zip_Code " +
                                 ") " +
                                 "VALUES('" + txtEmpID.Text + "','" + txtName.Text + "','" + txtSurname.Text + "','" + dateTimePicker1.Value + "','" + txtJobPosition.Text + "','" + txtShift.Text + "','" + txtEmail.Text + "','"
                                 + txtCellNumber.Text + "','" + txtHouseNumber.Text + "','" + txtStreetName.Text + "','" + txtSuburb.Text + "','" + txtZipCode.Text + "')";
                    SqlCommand command = new SqlCommand(sql, connection);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Employee details successfully saved");
                    connection.Close();
                }
            } 
            catch (Exception ex) 
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
           
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Edit_Employee empEd = new Edit_Employee();
            empEd.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options op = new Options();
            op.Show();
        }

        private void txtName_OnValueChanged(object sender, EventArgs e)
        {

        }
    }
}
