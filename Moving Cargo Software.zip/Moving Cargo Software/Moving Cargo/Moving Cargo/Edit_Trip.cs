﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Edit_Trip : Form
    {
        public Edit_Trip()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options op = new Options();
            op.Show();
        }

        private void btnAddTrip_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "UPDATE Booking_Trip SET Driver_Num = '" + txtDriverNumber.Text + "', " +
                                                  "Customer_ID= '" + txtCustomerID.Text + "', Booking_Price = '" + txtBookingPrice.Text + "', Trip_Num = '" + txtTripNumber.Text + "'," +
                                                  " Cargo = '" + txtCargoType.Text + "', Confirmation_Order = '" + txtConfirmation.Text + "', Date_Ordered = '" + dateTimePicker1.Value+ "', Zip_Code = '" + txtZipCode.Text + "', Street_Name = '" + txtStreetName.Text + "', Suburb= '" + txtSuburb.Text + "', Approval= '" + txtApproval.Text + "'" +
                                                  "WHERE Booking_Num = '" +cmbBookingNumber.Text + "'";
                SqlCommand command = new SqlCommand(sql, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Trip details successfully updated!!!");

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Edit_Trip_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Booking_Trip";
                SqlCommand command = new SqlCommand(sql, connection);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cmbBookingNumber.Items.Add(reader[0].ToString());
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
        }

        private void CmbBookingNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Booking_Trip";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (cmbBookingNumber.Text.Equals(reader[0].ToString()))
                    {
                        check = true;
                        txtCustomerID.Text = reader[2].ToString();
                        txtDriverNumber.Text = reader[1].ToString();
                        txtBookingPrice.Text = reader[3].ToString();


                        break;
                    }


                }
                if (check == true)
                {

                    MessageBox.Show("You can start editing Trip details \n" + "For Customer ID: " + reader[2].ToString() + "\n" + "Driver Number: " + reader[1].ToString());

                }
                else if (check == false)
                {
                    MessageBox.Show("The Trip ID you chose doesn't match any in the database!!!! ");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occured: " + ex.Message);

            }
        }

        private void panelRight_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
