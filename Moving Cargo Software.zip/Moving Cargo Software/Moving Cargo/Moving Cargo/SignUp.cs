﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click_1(object sender, EventArgs e)
        {
            Application.Exit();        
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            //After the user has been save then goes to login
            try 
            {
                if (txtPassword.Text.Equals("") || txtRePassword2.Text.Equals("") || txtUsername.Text.Equals(""))
                {
                    MessageBox.Show("Please fill in fields", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (txtPassword.Text != txtRePassword2.Text)
                {

                    MessageBox.Show("Both passwords must be the same");

                }
                else if (txtContactNumber.Text.Length < 10 || txtContactNumber.Text.Length > 10)
                {
                    MessageBox.Show("The CellPhone number should be 10 digits" );
                }
                else
                {
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "INSERT INTO Users (Username, UserPassword, Name, Surname, Email_Address, Contact_Number) " +
                                 "VALUES('" + txtUsername.Text + "','" + txtPassword.Text + "','" + txtContactNumber.Text + "','" + txtSurname.Text + "','" + txtEmail.Text + "','" + Convert.ToInt32(txtContactNumber.Text) + "')";
                    SqlCommand command = new SqlCommand(sql, connection);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Login Credentails successfully saved!!!");
                    connection.Close();
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("An error occurred:"+ ex.Message);
            }
            
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.Show();
        }


        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        
    }
}
