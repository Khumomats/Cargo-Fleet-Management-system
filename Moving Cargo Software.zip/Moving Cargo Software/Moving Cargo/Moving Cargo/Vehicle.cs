﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Vehicle : Form
    {
        public Vehicle()
        {
            InitializeComponent();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {

            this.Hide();
            Edit_Vehicle ev = new Edit_Vehicle();
            ev.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {

            this.Hide();
            Options p = new Options();
            p.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSaveVehicle_Click(object sender, EventArgs e)
        {

            //Checks if fields are empty
            if (txtAvaliableTrips.Text.Equals("") || txtCurrentOdometer.Text.Equals("") || txtVehicleNumber.Text.Length < 4 )
            {
                MessageBox.Show("Please check for any empty fields");
            }
            else
            {
                savingInfo();
            }


        }





        void savingInfo()
        {
            try
            {
                
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");

                connection.Open();
                string sql = "INSERT INTO Vehicle_Info(Vehicle_Num, Reg_Num, Vehicle_Type, Manufacturer, Engine_Size, Current_Odometer, Next_Service, Num_Trips ,Avail_Trips)" +
                            "VALUES ('"+txtVehicleNumber.Text+"','"+txtRegNumber.Text+"','"+txtVehicleType.Text+"','"+txtManufacturer.Text+"','"+txtEngineSize.Text+"','"+txtCurrentOdometer.Text+"','"+txtNextService.Text+"','"+txtNumberOfTrips.Text+"', '"+txtAvaliableTrips.Text+"')";
                    
                    
                   

                SqlCommand command = new SqlCommand(sql, connection);
                //command.Parameters.AddWithValue("@Vehicle_Num", txtVehicleNumber.Text);
                //command.Parameters.AddWithValue("@Reg_Num", txtRegNumber.Text);
                //command.Parameters.AddWithValue("@Vehicle_Type",txtVehicleType.Text);
                //command.Parameters.AddWithValue("@Manufacturer", txtManufacturer.Text);
                //command.Parameters.AddWithValue("@Engine_Size", txtEngineSize.Text);
                //command.Parameters.AddWithValue("@Current_Odometer", txtCurrentOdometer.Text);
                //command.Parameters.AddWithValue("@Next_Service", txtNextService.Text);
                //command.Parameters.AddWithValue("@Available_Trips", txtAvaliableTrips.Text);
               
                command.ExecuteNonQuery();
                MessageBox.Show("Vehicle details successfully saved");
                connection.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            VehilceReport report = new VehilceReport();
            report.Show();
        }
    }
}
