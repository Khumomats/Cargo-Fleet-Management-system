﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

           
            holdLogin();
            

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignUp sign = new SignUp();
            sign.Show();
        }
        //Login Code
        private void holdLogin() 
        {
            try
            {

                if (txtPassword.Text.Equals("") || txtUserName.Text.Equals(""))
                {
                    MessageBox.Show("Please fill in these fields", "Alert");
                }
                else
                {

                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "SELECT * FROM Users";
                    SqlCommand command = new SqlCommand(sql, connection);
                    bool check = false;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        if (reader[1].Equals(txtUserName.Text) && reader[2].Equals(txtPassword.Text))
                        {
                            check = true;
                        }
                    }
                    if (check == true)
                    {
                        if (rdGeneral.Checked)
                        {
                            this.Hide();
                            Options p = new Options();
                            p.Show();
                        }
                        else if (rdTripManager.Checked)
                        {
                            this.Hide();
                            TimeSheetForm form = new TimeSheetForm();
                            form.Show();
                        }
                    }
                    

              
                    else
                    {

                        MessageBox.Show("Plase provide valid login details");
                    }
                    connection.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);

            }
        }
    }
}
