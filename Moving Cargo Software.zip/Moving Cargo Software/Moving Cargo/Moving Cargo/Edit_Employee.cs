﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Edit_Employee : Form
    {
        public Edit_Employee()
        {
            InitializeComponent();
        }

        private void btnBAck_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options p = new Options();
            p.Show();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCellNumber.Text.Length < 10 || txtCellNumber.Text.Length > 10)
                {
                    MessageBox.Show("Please provide 10 digits for contact number");
                }
                else
                {
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "UPDATE Employee SET Employee_Name = '" + txtName.Text + "', Employee_Surname  = '" + txtSurname.Text + "', " +
                                                      "Date_Of_Birth= '" + dateTimePicker1.Value + "', Employee_Shift_Hours = '" + txtShift.Text + "'," +
                                                      " Employee_Email = '" + txtStreetName.Text + "', Employee_Cell_Num= '" + txtCellNumber.Text + "', House_Num = '" + txtHouseNumber.Text + "', Suburb= '" + txtSuburb.Text + "', Zip_Code= '" + txtZipCode.Text + "',  Job_Position = '" + txtJobPosition.Text + "'" +
                                                      "WHERE Employee_ID= '" + cmbEmployeeID.Text + "'";
                    SqlCommand command = new SqlCommand(sql, connection);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Employee details successfully updated!!!:");
                }

            } catch (Exception ex) 
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void comboID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Employee";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (reader[0].Equals(cmbEmployeeID.Text))
                    {
                        check = true;
                        txtName.Text = reader[1].ToString();
                        txtSurname.Text = reader[2].ToString();
                        dateTimePicker1.Text = reader[3].ToString();
                        txtShift.Text = reader[4].ToString();
                        txtEmailAddress.Text = reader[5].ToString();
                        txtCellNumber.Text = reader[6].ToString();
                        txtHouseNumber.Text = reader[7].ToString();
                        txtStreetName.Text = reader[8].ToString();
                        txtSuburb.Text = reader[9].ToString();
                        txtZipCode.Text = reader[10].ToString();
                        txtJobPosition.Text = reader[11].ToString();
                        break;
                    }


                }
                if (check == true) 
                {
                    MessageBox.Show("you can start editing Employee details \n" + " For Name : " + reader[1].ToString() + "\n" + " Surname: " + reader[2].ToString());
                }
                else if(check == false)
                {
                    MessageBox.Show("The Employee ID you chose doesn't match any in the database!!!! ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occured: " + ex.Message);

            }

        }
        private void Edit_Employee_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Employee";
                SqlCommand command = new SqlCommand(sql, connection);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cmbEmployeeID.Items.Add(reader[0].ToString());
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtCellNumber_OnValueChanged(object sender, EventArgs e)
        {
           
        }

       
    }
}
