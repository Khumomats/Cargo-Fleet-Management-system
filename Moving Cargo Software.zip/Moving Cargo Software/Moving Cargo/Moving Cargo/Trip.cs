﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace Moving_Cargo
{
    public partial class Trip : Form
    {
        string sq = "";
        int count = 0;
        private int hold = 0;
        public Trip()
        {
            InitializeComponent();
        }

        private void btnEditVehicle_Click(object sender, EventArgs e)
        {
            
            TripReport report = new TripReport();
            report.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options op = new Options();
            op.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAddTrip_Click(object sender, EventArgs e)
        {

            try
            {
                if (txtStreetName.Text.Equals(""))
                {

                }
                else
                {
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "INSERT INTO Booking_Trip" +
                                 "(" +
                                 "Driver_Num,Customer_ID, Booking_Price, Trip_Num,Cargo, Confirmation_Order, Date_Ordered, Zip_Code, Street_Name, Suburb, Approval " +
                                 ") " +
                                 "VALUES('"+cmbDriverNum.Text+"','"+cmbCustomerID.Text+"','" + txtBookingPrice.Text + "','"+cmbTripNumber.Text+"','" + txtCargoType.Text + "','" + txtConfirmation.Text + "','" + dateTimePicker1.Value + "',' " + txtZipCode.Text + "','" + txtStreetName.Text + "','" + txtSuburb.Text + "','" + txtApproval.Text + "')";
                    SqlCommand command = new SqlCommand(sql, connection);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Trip Order details successfully saved");
                    connection.Close();
                }

                


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void cmbCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Customers";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (cmbCustomerID.Text.Equals(reader[0].ToString()))
                    {
                        check = true;
                        txtStreetName.Text = reader[6].ToString();
                        txtSuburb.Text = reader[7].ToString();
                        txtZipCode.Text = reader[8].ToString();
                        
                        break;
                    }
                }
                if (check == true)
                {
                    MessageBox.Show("Customer ID has been found: " + reader[2].ToString() + "For Name : " + "\n" + reader[1].ToString());
                }
                else if (check == false)
                {
                    MessageBox.Show("Customer ID not found");
                }



            }
            catch (Exception ex) 
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void cmbDriverNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
               
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "SELECT * FROM Driver";
                    SqlCommand command = new SqlCommand(sql, connection);
                    bool check = false;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        if (cmbDriverNum.Text.Equals(reader[0].ToString()))
                        {
                            check = true;
                            txtDriverName.Text = reader[1].ToString();
                            txtDriverSurname.Text = reader[2].ToString();
                            
                            break;
                        }
                    }
                    if (check == true)
                    {
                        MessageBox.Show("Driver ID has been found: " + reader[0].ToString() + "For Name : " + "\n" + reader[1].ToString());
                    }
                    else if (check == false)
                    {
                        MessageBox.Show("Driver ID not available");
                    }
                
                
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void Trip_Load(object sender, EventArgs e)
        {
            try 
            {
                TripNumber();
                DriverNumber();
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Customers";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    check = true;
                    cmbCustomerID.Items.Add(reader[0].ToString());
                    
                }

            } 
            catch (Exception ex) 
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private String DriverNumber() 
        {
            try 
            {
               
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Driver";
                SqlCommand command = new SqlCommand(sql, connection);
                
                int count = 0;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    
                    cmbDriverNum.Items.Add(reader[0].ToString());
                    
                    
                    
                }

                return sq;
            }
            catch(Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return sq;

        }
        private String TripNumber()
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Trips";
                SqlCommand command = new SqlCommand(sql, connection);

                int count = 0;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {

                    cmbTripNumber.Items.Add(reader[0].ToString());



                }

                return sq;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return sq;

        }

        private void cmbTripNumber_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
