﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Moving_Cargo
{
    public partial class Driver : Form
    {
        public Driver()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();       
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            //Open edit driver
            this.Hide();
            Edit_Driver ed = new Edit_Driver();
            ed.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options p = new Options();
            p.ShowDialog();
        }
        private void btnAddDriver_Click(object sender, EventArgs e)
        {
            try
            {
                 SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                 connection.Open();
                 string sql = "INSERT INTO Driver" +
                                 "(" +
                                 " Driver_Name, Driver_Surname,Driver_DOB,Driver_ID, Driver_Email,Driver_Cell, Street_Name, House_Num, Suburb, ZipCode" +
                                 ") " +
                                 "VALUES('" + txtName.Text + "','" + txtSurname.Text + "','" + dateTimePicker1.Value + "','" + txtDriverID.Text + "','" + txtEmail.Text + "','" + Convert.ToInt32(txtCellNumber.Text) + "','" + txtStreetName.Text + "','"
                                 + txtHouseNumber.Text + "','" + txtSuburb.Text + "','" + txtZipCode.Text + "')";
                  SqlCommand command = new SqlCommand(sql, connection);

                  command.ExecuteNonQuery();
                  MessageBox.Show("Driver details successfully saved");
                  connection.Close();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void panelRight_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtStreetName_OnValueChanged(object sender, EventArgs e)
        {

        }

        
    }
}
