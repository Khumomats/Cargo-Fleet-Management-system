﻿namespace Moving_Cargo
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Employee));
            this.panelLeft = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnCustomerSave = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.panelRight = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtStreetName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtShift = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtCellNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtEmail = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtEmpID = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSurname = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtZipCode = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSuburb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtJobPosition = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtHouseNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelRight.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.DarkCyan;
            this.panelLeft.Controls.Add(this.label1);
            this.panelLeft.Controls.Add(this.pictureBox1);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(321, 608);
            this.panelLeft.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(52, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Our employee";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(83, 158);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(158, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkCyan;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(21, 488);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(297, 34);
            this.button1.TabIndex = 3;
            this.button1.Text = "Edit employee";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCustomerSave
            // 
            this.btnCustomerSave.BackColor = System.Drawing.Color.DarkCyan;
            this.btnCustomerSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomerSave.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomerSave.ForeColor = System.Drawing.Color.White;
            this.btnCustomerSave.Location = new System.Drawing.Point(21, 436);
            this.btnCustomerSave.Name = "btnCustomerSave";
            this.btnCustomerSave.Size = new System.Drawing.Size(297, 34);
            this.btnCustomerSave.TabIndex = 2;
            this.btnCustomerSave.Text = "Add employee";
            this.btnCustomerSave.UseVisualStyleBackColor = false;
            this.btnCustomerSave.Click += new System.EventHandler(this.btnCustomerSave_Click);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 25;
            this.bunifuElipse1.TargetControl = this;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkCyan;
            this.label8.Location = new System.Drawing.Point(646, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 30);
            this.label8.TabIndex = 0;
            this.label8.Text = "x";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // panelRight
            // 
            this.panelRight.Controls.Add(this.dateTimePicker1);
            this.panelRight.Controls.Add(this.txtStreetName);
            this.panelRight.Controls.Add(this.txtShift);
            this.panelRight.Controls.Add(this.txtCellNumber);
            this.panelRight.Controls.Add(this.txtName);
            this.panelRight.Controls.Add(this.txtEmail);
            this.panelRight.Controls.Add(this.txtEmpID);
            this.panelRight.Controls.Add(this.txtSurname);
            this.panelRight.Controls.Add(this.label15);
            this.panelRight.Controls.Add(this.label2);
            this.panelRight.Controls.Add(this.txtZipCode);
            this.panelRight.Controls.Add(this.label14);
            this.panelRight.Controls.Add(this.txtSuburb);
            this.panelRight.Controls.Add(this.label12);
            this.panelRight.Controls.Add(this.txtJobPosition);
            this.panelRight.Controls.Add(this.label13);
            this.panelRight.Controls.Add(this.label5);
            this.panelRight.Controls.Add(this.txtHouseNumber);
            this.panelRight.Controls.Add(this.label9);
            this.panelRight.Controls.Add(this.label10);
            this.panelRight.Controls.Add(this.label11);
            this.panelRight.Controls.Add(this.label7);
            this.panelRight.Controls.Add(this.label6);
            this.panelRight.Controls.Add(this.label4);
            this.panelRight.Controls.Add(this.btnBack);
            this.panelRight.Controls.Add(this.button1);
            this.panelRight.Controls.Add(this.btnCustomerSave);
            this.panelRight.Controls.Add(this.label8);
            this.panelRight.Location = new System.Drawing.Point(327, 3);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(683, 604);
            this.panelRight.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(21, 265);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(297, 20);
            this.dateTimePicker1.TabIndex = 91;
            // 
            // txtStreetName
            // 
            this.txtStreetName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtStreetName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtStreetName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtStreetName.HintForeColor = System.Drawing.Color.Empty;
            this.txtStreetName.HintText = "";
            this.txtStreetName.isPassword = false;
            this.txtStreetName.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtStreetName.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtStreetName.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtStreetName.LineThickness = 3;
            this.txtStreetName.Location = new System.Drawing.Point(357, 195);
            this.txtStreetName.Margin = new System.Windows.Forms.Padding(4);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(297, 31);
            this.txtStreetName.TabIndex = 90;
            this.txtStreetName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtShift
            // 
            this.txtShift.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtShift.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtShift.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtShift.HintForeColor = System.Drawing.Color.Empty;
            this.txtShift.HintText = "";
            this.txtShift.isPassword = false;
            this.txtShift.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtShift.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtShift.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtShift.LineThickness = 3;
            this.txtShift.Location = new System.Drawing.Point(21, 398);
            this.txtShift.Margin = new System.Windows.Forms.Padding(4);
            this.txtShift.Name = "txtShift";
            this.txtShift.Size = new System.Drawing.Size(297, 31);
            this.txtShift.TabIndex = 79;
            this.txtShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCellNumber
            // 
            this.txtCellNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCellNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCellNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCellNumber.HintForeColor = System.Drawing.Color.Empty;
            this.txtCellNumber.HintText = "";
            this.txtCellNumber.isPassword = false;
            this.txtCellNumber.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtCellNumber.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtCellNumber.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtCellNumber.LineThickness = 3;
            this.txtCellNumber.Location = new System.Drawing.Point(357, 66);
            this.txtCellNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtCellNumber.Name = "txtCellNumber";
            this.txtCellNumber.Size = new System.Drawing.Size(297, 31);
            this.txtCellNumber.TabIndex = 78;
            this.txtCellNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtName
            // 
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtName.HintForeColor = System.Drawing.Color.Empty;
            this.txtName.HintText = "";
            this.txtName.isPassword = false;
            this.txtName.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtName.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtName.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtName.LineThickness = 3;
            this.txtName.Location = new System.Drawing.Point(21, 136);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(297, 31);
            this.txtName.TabIndex = 77;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtName.OnValueChanged += new System.EventHandler(this.txtName_OnValueChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmail.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEmail.HintForeColor = System.Drawing.Color.Empty;
            this.txtEmail.HintText = "";
            this.txtEmail.isPassword = false;
            this.txtEmail.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtEmail.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtEmail.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtEmail.LineThickness = 3;
            this.txtEmail.Location = new System.Drawing.Point(357, 136);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(297, 31);
            this.txtEmail.TabIndex = 76;
            this.txtEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtEmpID
            // 
            this.txtEmpID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmpID.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtEmpID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEmpID.HintForeColor = System.Drawing.Color.Empty;
            this.txtEmpID.HintText = "";
            this.txtEmpID.isPassword = false;
            this.txtEmpID.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtEmpID.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtEmpID.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtEmpID.LineThickness = 3;
            this.txtEmpID.Location = new System.Drawing.Point(21, 66);
            this.txtEmpID.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmpID.Name = "txtEmpID";
            this.txtEmpID.Size = new System.Drawing.Size(297, 31);
            this.txtEmpID.TabIndex = 75;
            this.txtEmpID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSurname
            // 
            this.txtSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSurname.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtSurname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSurname.HintForeColor = System.Drawing.Color.Empty;
            this.txtSurname.HintText = "";
            this.txtSurname.isPassword = false;
            this.txtSurname.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtSurname.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtSurname.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtSurname.LineThickness = 3;
            this.txtSurname.Location = new System.Drawing.Point(21, 196);
            this.txtSurname.Margin = new System.Windows.Forms.Padding(4);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(297, 31);
            this.txtSurname.TabIndex = 74;
            this.txtSurname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.DarkCyan;
            this.label15.Location = new System.Drawing.Point(353, 171);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(113, 21);
            this.label15.TabIndex = 59;
            this.label15.Text = "Street Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkCyan;
            this.label2.Location = new System.Drawing.Point(17, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 21);
            this.label2.TabIndex = 58;
            this.label2.Text = "Employee ID:";
            // 
            // txtZipCode
            // 
            this.txtZipCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtZipCode.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtZipCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtZipCode.HintForeColor = System.Drawing.Color.Empty;
            this.txtZipCode.HintText = "";
            this.txtZipCode.isPassword = false;
            this.txtZipCode.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtZipCode.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtZipCode.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtZipCode.LineThickness = 3;
            this.txtZipCode.Location = new System.Drawing.Point(357, 398);
            this.txtZipCode.Margin = new System.Windows.Forms.Padding(4);
            this.txtZipCode.Name = "txtZipCode";
            this.txtZipCode.Size = new System.Drawing.Size(297, 31);
            this.txtZipCode.TabIndex = 57;
            this.txtZipCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DarkCyan;
            this.label14.Location = new System.Drawing.Point(353, 372);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 21);
            this.label14.TabIndex = 56;
            this.label14.Text = "Zip Code:";
            // 
            // txtSuburb
            // 
            this.txtSuburb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSuburb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtSuburb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSuburb.HintForeColor = System.Drawing.Color.Empty;
            this.txtSuburb.HintText = "";
            this.txtSuburb.isPassword = false;
            this.txtSuburb.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtSuburb.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtSuburb.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtSuburb.LineThickness = 3;
            this.txtSuburb.Location = new System.Drawing.Point(357, 330);
            this.txtSuburb.Margin = new System.Windows.Forms.Padding(4);
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.Size = new System.Drawing.Size(297, 31);
            this.txtSuburb.TabIndex = 55;
            this.txtSuburb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DarkCyan;
            this.label12.Location = new System.Drawing.Point(353, 305);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 21);
            this.label12.TabIndex = 54;
            this.label12.Text = "Suburb:";
            // 
            // txtJobPosition
            // 
            this.txtJobPosition.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtJobPosition.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtJobPosition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtJobPosition.HintForeColor = System.Drawing.Color.Empty;
            this.txtJobPosition.HintText = "";
            this.txtJobPosition.isPassword = false;
            this.txtJobPosition.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtJobPosition.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtJobPosition.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtJobPosition.LineThickness = 3;
            this.txtJobPosition.Location = new System.Drawing.Point(21, 331);
            this.txtJobPosition.Margin = new System.Windows.Forms.Padding(4);
            this.txtJobPosition.Name = "txtJobPosition";
            this.txtJobPosition.Size = new System.Drawing.Size(297, 31);
            this.txtJobPosition.TabIndex = 53;
            this.txtJobPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkCyan;
            this.label13.Location = new System.Drawing.Point(17, 306);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 21);
            this.label13.TabIndex = 52;
            this.label13.Text = "Job Position:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkCyan;
            this.label5.Location = new System.Drawing.Point(353, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 21);
            this.label5.TabIndex = 50;
            this.label5.Text = "Cell Number:";
            // 
            // txtHouseNumber
            // 
            this.txtHouseNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtHouseNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtHouseNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtHouseNumber.HintForeColor = System.Drawing.Color.Empty;
            this.txtHouseNumber.HintText = "";
            this.txtHouseNumber.isPassword = false;
            this.txtHouseNumber.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtHouseNumber.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtHouseNumber.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtHouseNumber.LineThickness = 3;
            this.txtHouseNumber.Location = new System.Drawing.Point(357, 255);
            this.txtHouseNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtHouseNumber.Name = "txtHouseNumber";
            this.txtHouseNumber.Size = new System.Drawing.Size(297, 31);
            this.txtHouseNumber.TabIndex = 49;
            this.txtHouseNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkCyan;
            this.label9.Location = new System.Drawing.Point(353, 230);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 21);
            this.label9.TabIndex = 44;
            this.label9.Text = "House Number:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkCyan;
            this.label10.Location = new System.Drawing.Point(353, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 21);
            this.label10.TabIndex = 45;
            this.label10.Text = "Email Address:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkCyan;
            this.label11.Location = new System.Drawing.Point(17, 381);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 21);
            this.label11.TabIndex = 46;
            this.label11.Text = "Shift hours";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkCyan;
            this.label7.Location = new System.Drawing.Point(17, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 21);
            this.label7.TabIndex = 42;
            this.label7.Text = " Surname:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkCyan;
            this.label6.Location = new System.Drawing.Point(17, 238);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 21);
            this.label6.TabIndex = 37;
            this.label6.Text = "Date of birth:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkCyan;
            this.label4.Location = new System.Drawing.Point(17, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 21);
            this.label4.TabIndex = 36;
            this.label4.Text = "Name:";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.DarkCyan;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(21, 538);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(297, 34);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Back to options";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panelLeft;
            this.bunifuDragControl1.Vertical = true;
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 608);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.panelRight);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Employee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee";
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelRight.ResumeLayout(false);
            this.panelRight.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnCustomerSave;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtZipCode;
        private System.Windows.Forms.Label label14;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSuburb;
        private System.Windows.Forms.Label label12;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtJobPosition;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label5;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtHouseNumber;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtShift;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtCellNumber;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtEmail;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtEmpID;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSurname;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtStreetName;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}