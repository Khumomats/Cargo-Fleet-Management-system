﻿namespace Moving_Cargo
{
    partial class Service
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Service));
            this.txtServiceNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnService = new System.Windows.Forms.Button();
            this.txtAppointment = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtVehicleDescription = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panelRight = new System.Windows.Forms.Panel();
            this.txtServiceDescription = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbVehicleNumber = new System.Windows.Forms.ComboBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelLeft.SuspendLayout();
            this.panelRight.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtServiceNumber
            // 
            this.txtServiceNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtServiceNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtServiceNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtServiceNumber.HintForeColor = System.Drawing.Color.Empty;
            this.txtServiceNumber.HintText = "";
            this.txtServiceNumber.isPassword = true;
            this.txtServiceNumber.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtServiceNumber.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtServiceNumber.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtServiceNumber.LineThickness = 3;
            this.txtServiceNumber.Location = new System.Drawing.Point(16, 128);
            this.txtServiceNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtServiceNumber.Name = "txtServiceNumber";
            this.txtServiceNumber.Size = new System.Drawing.Size(297, 31);
            this.txtServiceNumber.TabIndex = 22;
            this.txtServiceNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkCyan;
            this.label5.Location = new System.Drawing.Point(12, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 21);
            this.label5.TabIndex = 21;
            this.label5.Text = "Service Number:";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.DarkCyan;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.Location = new System.Drawing.Point(21, 368);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(297, 34);
            this.btnBack.TabIndex = 20;
            this.btnBack.Text = "Back to options";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnService
            // 
            this.btnService.BackColor = System.Drawing.Color.DarkCyan;
            this.btnService.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnService.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnService.ForeColor = System.Drawing.Color.White;
            this.btnService.Location = new System.Drawing.Point(21, 314);
            this.btnService.Name = "btnService";
            this.btnService.Size = new System.Drawing.Size(297, 34);
            this.btnService.TabIndex = 2;
            this.btnService.Text = "Save";
            this.btnService.UseVisualStyleBackColor = false;
            this.btnService.Click += new System.EventHandler(this.btnService_Click);
            // 
            // txtAppointment
            // 
            this.txtAppointment.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAppointment.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtAppointment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtAppointment.HintForeColor = System.Drawing.Color.Empty;
            this.txtAppointment.HintText = "";
            this.txtAppointment.isPassword = true;
            this.txtAppointment.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtAppointment.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtAppointment.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtAppointment.LineThickness = 3;
            this.txtAppointment.Location = new System.Drawing.Point(16, 268);
            this.txtAppointment.Margin = new System.Windows.Forms.Padding(4);
            this.txtAppointment.Name = "txtAppointment";
            this.txtAppointment.Size = new System.Drawing.Size(297, 31);
            this.txtAppointment.TabIndex = 1;
            this.txtAppointment.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkCyan;
            this.label4.Location = new System.Drawing.Point(17, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(188, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "Appointment Number:";
            // 
            // txtVehicleDescription
            // 
            this.txtVehicleDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtVehicleDescription.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtVehicleDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtVehicleDescription.HintForeColor = System.Drawing.Color.Empty;
            this.txtVehicleDescription.HintText = "";
            this.txtVehicleDescription.isPassword = false;
            this.txtVehicleDescription.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtVehicleDescription.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtVehicleDescription.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtVehicleDescription.LineThickness = 3;
            this.txtVehicleDescription.Location = new System.Drawing.Point(339, 199);
            this.txtVehicleDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtVehicleDescription.Name = "txtVehicleDescription";
            this.txtVehicleDescription.Size = new System.Drawing.Size(297, 31);
            this.txtVehicleDescription.TabIndex = 1;
            this.txtVehicleDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkCyan;
            this.label3.Location = new System.Drawing.Point(12, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "Vehicle Number:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkCyan;
            this.label8.Location = new System.Drawing.Point(649, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 30);
            this.label8.TabIndex = 0;
            this.label8.Text = "x";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkCyan;
            this.label2.Location = new System.Drawing.Point(16, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 30);
            this.label2.TabIndex = 0;
            this.label2.Text = "Service vehicle";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(52, 314);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(274, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "Service vehicle";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(66, 103);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(190, 196);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.DarkCyan;
            this.panelLeft.Controls.Add(this.label1);
            this.panelLeft.Controls.Add(this.pictureBox1);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(321, 474);
            this.panelLeft.TabIndex = 6;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panelLeft;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 25;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panelRight
            // 
            this.panelRight.Controls.Add(this.txtServiceDescription);
            this.panelRight.Controls.Add(this.label7);
            this.panelRight.Controls.Add(this.btnGenerate);
            this.panelRight.Controls.Add(this.label6);
            this.panelRight.Controls.Add(this.cmbVehicleNumber);
            this.panelRight.Controls.Add(this.txtServiceNumber);
            this.panelRight.Controls.Add(this.label5);
            this.panelRight.Controls.Add(this.btnBack);
            this.panelRight.Controls.Add(this.btnService);
            this.panelRight.Controls.Add(this.txtAppointment);
            this.panelRight.Controls.Add(this.label4);
            this.panelRight.Controls.Add(this.txtVehicleDescription);
            this.panelRight.Controls.Add(this.label3);
            this.panelRight.Controls.Add(this.label8);
            this.panelRight.Controls.Add(this.label2);
            this.panelRight.Location = new System.Drawing.Point(327, 0);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(677, 462);
            this.panelRight.TabIndex = 7;
            this.panelRight.Paint += new System.Windows.Forms.PaintEventHandler(this.panelRight_Paint);
            // 
            // txtServiceDescription
            // 
            this.txtServiceDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtServiceDescription.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtServiceDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtServiceDescription.HintForeColor = System.Drawing.Color.Empty;
            this.txtServiceDescription.HintText = "";
            this.txtServiceDescription.isPassword = true;
            this.txtServiceDescription.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtServiceDescription.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtServiceDescription.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtServiceDescription.LineThickness = 3;
            this.txtServiceDescription.Location = new System.Drawing.Point(339, 138);
            this.txtServiceDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtServiceDescription.Name = "txtServiceDescription";
            this.txtServiceDescription.Size = new System.Drawing.Size(297, 21);
            this.txtServiceDescription.TabIndex = 27;
            this.txtServiceDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkCyan;
            this.label7.Location = new System.Drawing.Point(335, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(161, 21);
            this.label7.TabIndex = 26;
            this.label7.Text = "Service Description:";
            // 
            // btnGenerate
            // 
            this.btnGenerate.BackColor = System.Drawing.Color.DarkCyan;
            this.btnGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGenerate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.ForeColor = System.Drawing.Color.White;
            this.btnGenerate.Location = new System.Drawing.Point(21, 425);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(297, 34);
            this.btnGenerate.TabIndex = 25;
            this.btnGenerate.Text = "Generate Report";
            this.btnGenerate.UseVisualStyleBackColor = false;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkCyan;
            this.label6.Location = new System.Drawing.Point(335, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 21);
            this.label6.TabIndex = 24;
            this.label6.Text = "Vehicle Description";
            // 
            // cmbVehicleNumber
            // 
            this.cmbVehicleNumber.FormattingEnabled = true;
            this.cmbVehicleNumber.Location = new System.Drawing.Point(16, 204);
            this.cmbVehicleNumber.Name = "cmbVehicleNumber";
            this.cmbVehicleNumber.Size = new System.Drawing.Size(239, 21);
            this.cmbVehicleNumber.TabIndex = 23;
            // 
            // Service
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 474);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.panelRight);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Service";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Service";
            this.Load += new System.EventHandler(this.Service_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            this.panelRight.ResumeLayout(false);
            this.panelRight.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuMaterialTextbox txtServiceNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnService;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtAppointment;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtVehicleDescription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelLeft;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panelRight;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbVehicleNumber;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtServiceDescription;
        private System.Windows.Forms.Label label7;
    }
}