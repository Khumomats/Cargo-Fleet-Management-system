﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Edit_Customer ec = new Edit_Customer();
            ec.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options option = new Options();
            option.Show();
        }

        private void txtZipCode_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void btnCustomerSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCustomerID.Text.Length < 13 || txtCustomerID.Text.Length > 13)
                {
                    MessageBox.Show("Customer ID should be 13 digits");
                }
                else if (txtPhoneNumber.Text.Length < 10 || txtPhoneNumber.Text.Length > 10)
                {
                    MessageBox.Show("Phone Number should be 10 digits");
                }
                else 
                {
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "INSERT INTO Customers (Customer_ID, Customer_Name, Customer_Surname, Customer_Cell_Num, Customer_Email, House_Num, Street_Name, Suburb, ZipCode) " +
                                 "VALUES('" + txtCustomerID.Text + "','" + txtName.Text + "','" + txtSurname.Text + "','" + txtPhoneNumber.Text + "','" + txtEmail.Text + "','" + txtHouseNumber.Text + "','" + txtStreetName.Text + "','" + txtSuburb.Text + "','" + txtZipCode.Text + "')";
                    SqlCommand command = new SqlCommand(sql, connection);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Customer details successfully saved");
                    connection.Close();
                }
                   

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred:" + ex.Message);
            }
        }
    }
}
