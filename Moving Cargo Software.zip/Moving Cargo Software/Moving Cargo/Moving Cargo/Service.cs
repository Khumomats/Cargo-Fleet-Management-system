﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Moving_Cargo
{
    public partial class Service : Form
    {
        public Service()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options p = new Options();
            p.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnService_Click(object sender, EventArgs e)
        {

            try
            {
                
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "INSERT INTO Service_Appointment" +
                                 "(" +
                                 "Service_Num, Appointment_Num, Vehicle_Num, Service_Description, Vehicle_Description" +
                                 ") " +
                                 "VALUES('" + txtServiceNumber.Text + "','" + txtAppointment.Text  + "','" + cmbVehicleNumber.Text + "','" + txtServiceDescription.Text+ "',' "+txtVehicleDescription.Text+"')";
                    SqlCommand command = new SqlCommand(sql, connection);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Service details successfully saved");
                    connection.Close();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void panelRight_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Service_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Vehicle_Info";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    check = true;
                    cmbVehicleNumber.Items.Add(reader[0].ToString());
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            ServiceReport report = new ServiceReport();
            report.Show();
        }
    }
}
