﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Moving_Cargo
{
    public partial class Edit_Order : Form
    {
        public Edit_Order()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {

            //Opens options form
            this.Hide();
            Options op = new Options();
            op.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Edit_Order_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
            connection.Open();
            string sql = "SELECT * FROM Trips";
            SqlCommand command = new SqlCommand(sql, connection);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cmbTripNumber.Items.Add(reader[0].ToString());
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occurred: " + ex.Message);
            }
        }

        private void btnSaveOrder_Click(object sender, EventArgs e)
        {
            try 
            {
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();

                string sql = "UPDATE Trips SET Trip_Schedule = '" + dateTimePicker1.Value + "', Distance  = '" + txtDistance.Text + "', " +
                                                                 "Trip_Status= '" + txtTripStatus.Text +"'";
                SqlCommand command = new SqlCommand(sql, connection);

                command.ExecuteNonQuery();
                MessageBox.Show("Orders details successfully saved");
                connection.Close();
            } 
            catch (Exception ex) 
            {
                MessageBox.Show("An error has occurred: " + ex.Message);
            }
           

        }

        private void cmbTripNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Trips";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (cmbTripNumber.Text.Equals(reader[0].ToString()))
                    {
                        check = true;
                        txtEmpID.Text = reader[1].ToString();
                        txtVehicleNumber.Text = reader[2].ToString();
                        txtCustomerID.Text = reader[3].ToString();
                        txtDriverNumber.Text = reader[3].ToString();

                        break;
                    }


                }
                if (check == true)
                {

                    MessageBox.Show("You can start editing Order details \n" + "For Name: " + reader[1].ToString() + "\n" + "Surname: " + reader[2].ToString());

                }
                else if (check == false)
                {
                    MessageBox.Show("The Customer ID you chose doesn't match any in the database!!!! ");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occured: " + ex.Message);

            }
        }
    }
}
