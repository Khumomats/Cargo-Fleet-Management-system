﻿namespace Moving_Cargo
{
    partial class Edit_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Edit_Employee));
            this.panelRight = new System.Windows.Forms.Panel();
            this.txtName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtShift = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtCellNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtEmailAddress = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtStreetName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtSurname = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtZipCode = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSuburb = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtJobPosition = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtHouseNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbEmployeeID = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnBAck = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panelLeft = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panelRight.SuspendLayout();
            this.panelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelRight
            // 
            this.panelRight.Controls.Add(this.dateTimePicker1);
            this.panelRight.Controls.Add(this.txtName);
            this.panelRight.Controls.Add(this.txtShift);
            this.panelRight.Controls.Add(this.txtCellNumber);
            this.panelRight.Controls.Add(this.txtEmailAddress);
            this.panelRight.Controls.Add(this.txtStreetName);
            this.panelRight.Controls.Add(this.txtSurname);
            this.panelRight.Controls.Add(this.label15);
            this.panelRight.Controls.Add(this.txtZipCode);
            this.panelRight.Controls.Add(this.label14);
            this.panelRight.Controls.Add(this.txtSuburb);
            this.panelRight.Controls.Add(this.label12);
            this.panelRight.Controls.Add(this.txtJobPosition);
            this.panelRight.Controls.Add(this.label13);
            this.panelRight.Controls.Add(this.label5);
            this.panelRight.Controls.Add(this.txtHouseNumber);
            this.panelRight.Controls.Add(this.label9);
            this.panelRight.Controls.Add(this.label10);
            this.panelRight.Controls.Add(this.label11);
            this.panelRight.Controls.Add(this.label7);
            this.panelRight.Controls.Add(this.label4);
            this.panelRight.Controls.Add(this.label16);
            this.panelRight.Controls.Add(this.cmbEmployeeID);
            this.panelRight.Controls.Add(this.label6);
            this.panelRight.Controls.Add(this.btnBAck);
            this.panelRight.Controls.Add(this.btnSave);
            this.panelRight.Controls.Add(this.label8);
            this.panelRight.Controls.Add(this.label2);
            this.panelRight.Location = new System.Drawing.Point(327, 0);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(942, 567);
            this.panelRight.TabIndex = 11;
            // 
            // txtName
            // 
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtName.HintForeColor = System.Drawing.Color.Empty;
            this.txtName.HintText = "";
            this.txtName.isPassword = false;
            this.txtName.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtName.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtName.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtName.LineThickness = 3;
            this.txtName.Location = new System.Drawing.Point(28, 164);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(297, 31);
            this.txtName.TabIndex = 89;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtShift
            // 
            this.txtShift.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtShift.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtShift.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtShift.HintForeColor = System.Drawing.Color.Empty;
            this.txtShift.HintText = "";
            this.txtShift.isPassword = false;
            this.txtShift.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtShift.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtShift.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtShift.LineThickness = 3;
            this.txtShift.Location = new System.Drawing.Point(21, 426);
            this.txtShift.Margin = new System.Windows.Forms.Padding(4);
            this.txtShift.Name = "txtShift";
            this.txtShift.Size = new System.Drawing.Size(297, 31);
            this.txtShift.TabIndex = 88;
            this.txtShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCellNumber
            // 
            this.txtCellNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCellNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCellNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCellNumber.HintForeColor = System.Drawing.Color.Empty;
            this.txtCellNumber.HintText = "";
            this.txtCellNumber.isPassword = false;
            this.txtCellNumber.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtCellNumber.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtCellNumber.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtCellNumber.LineThickness = 3;
            this.txtCellNumber.Location = new System.Drawing.Point(364, 82);
            this.txtCellNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtCellNumber.Name = "txtCellNumber";
            this.txtCellNumber.Size = new System.Drawing.Size(297, 31);
            this.txtCellNumber.TabIndex = 87;
            this.txtCellNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmailAddress.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtEmailAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtEmailAddress.HintForeColor = System.Drawing.Color.Empty;
            this.txtEmailAddress.HintText = "";
            this.txtEmailAddress.isPassword = false;
            this.txtEmailAddress.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtEmailAddress.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtEmailAddress.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtEmailAddress.LineThickness = 3;
            this.txtEmailAddress.Location = new System.Drawing.Point(364, 164);
            this.txtEmailAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(297, 31);
            this.txtEmailAddress.TabIndex = 86;
            this.txtEmailAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtStreetName
            // 
            this.txtStreetName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtStreetName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtStreetName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtStreetName.HintForeColor = System.Drawing.Color.Empty;
            this.txtStreetName.HintText = "";
            this.txtStreetName.isPassword = false;
            this.txtStreetName.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtStreetName.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtStreetName.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtStreetName.LineThickness = 3;
            this.txtStreetName.Location = new System.Drawing.Point(364, 223);
            this.txtStreetName.Margin = new System.Windows.Forms.Padding(4);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(297, 31);
            this.txtStreetName.TabIndex = 85;
            this.txtStreetName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtSurname
            // 
            this.txtSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSurname.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtSurname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSurname.HintForeColor = System.Drawing.Color.Empty;
            this.txtSurname.HintText = "";
            this.txtSurname.isPassword = false;
            this.txtSurname.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtSurname.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtSurname.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtSurname.LineThickness = 3;
            this.txtSurname.Location = new System.Drawing.Point(28, 224);
            this.txtSurname.Margin = new System.Windows.Forms.Padding(4);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(297, 31);
            this.txtSurname.TabIndex = 84;
            this.txtSurname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.DarkCyan;
            this.label15.Location = new System.Drawing.Point(360, 199);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(113, 21);
            this.label15.TabIndex = 83;
            this.label15.Text = "Street Name:";
            // 
            // txtZipCode
            // 
            this.txtZipCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtZipCode.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtZipCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtZipCode.HintForeColor = System.Drawing.Color.Empty;
            this.txtZipCode.HintText = "";
            this.txtZipCode.isPassword = false;
            this.txtZipCode.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtZipCode.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtZipCode.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtZipCode.LineThickness = 3;
            this.txtZipCode.Location = new System.Drawing.Point(364, 426);
            this.txtZipCode.Margin = new System.Windows.Forms.Padding(4);
            this.txtZipCode.Name = "txtZipCode";
            this.txtZipCode.Size = new System.Drawing.Size(297, 31);
            this.txtZipCode.TabIndex = 81;
            this.txtZipCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DarkCyan;
            this.label14.Location = new System.Drawing.Point(360, 400);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 21);
            this.label14.TabIndex = 80;
            this.label14.Text = "Zip Code:";
            // 
            // txtSuburb
            // 
            this.txtSuburb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSuburb.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtSuburb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSuburb.HintForeColor = System.Drawing.Color.Empty;
            this.txtSuburb.HintText = "";
            this.txtSuburb.isPassword = false;
            this.txtSuburb.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtSuburb.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtSuburb.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtSuburb.LineThickness = 3;
            this.txtSuburb.Location = new System.Drawing.Point(364, 358);
            this.txtSuburb.Margin = new System.Windows.Forms.Padding(4);
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.Size = new System.Drawing.Size(297, 31);
            this.txtSuburb.TabIndex = 79;
            this.txtSuburb.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DarkCyan;
            this.label12.Location = new System.Drawing.Point(360, 333);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 21);
            this.label12.TabIndex = 78;
            this.label12.Text = "Suburb:";
            // 
            // txtJobPosition
            // 
            this.txtJobPosition.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtJobPosition.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtJobPosition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtJobPosition.HintForeColor = System.Drawing.Color.Empty;
            this.txtJobPosition.HintText = "";
            this.txtJobPosition.isPassword = false;
            this.txtJobPosition.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtJobPosition.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtJobPosition.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtJobPosition.LineThickness = 3;
            this.txtJobPosition.Location = new System.Drawing.Point(28, 359);
            this.txtJobPosition.Margin = new System.Windows.Forms.Padding(4);
            this.txtJobPosition.Name = "txtJobPosition";
            this.txtJobPosition.Size = new System.Drawing.Size(297, 31);
            this.txtJobPosition.TabIndex = 77;
            this.txtJobPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkCyan;
            this.label13.Location = new System.Drawing.Point(24, 334);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(109, 21);
            this.label13.TabIndex = 76;
            this.label13.Text = "Job Position::";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkCyan;
            this.label5.Location = new System.Drawing.Point(363, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 21);
            this.label5.TabIndex = 74;
            this.label5.Text = "Cell Number:";
            // 
            // txtHouseNumber
            // 
            this.txtHouseNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtHouseNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtHouseNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtHouseNumber.HintForeColor = System.Drawing.Color.Empty;
            this.txtHouseNumber.HintText = "";
            this.txtHouseNumber.isPassword = false;
            this.txtHouseNumber.LineFocusedColor = System.Drawing.Color.DarkCyan;
            this.txtHouseNumber.LineIdleColor = System.Drawing.Color.DarkCyan;
            this.txtHouseNumber.LineMouseHoverColor = System.Drawing.Color.DarkCyan;
            this.txtHouseNumber.LineThickness = 3;
            this.txtHouseNumber.Location = new System.Drawing.Point(364, 283);
            this.txtHouseNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtHouseNumber.Name = "txtHouseNumber";
            this.txtHouseNumber.Size = new System.Drawing.Size(297, 31);
            this.txtHouseNumber.TabIndex = 73;
            this.txtHouseNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkCyan;
            this.label9.Location = new System.Drawing.Point(360, 258);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 21);
            this.label9.TabIndex = 68;
            this.label9.Text = "House Number:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkCyan;
            this.label10.Location = new System.Drawing.Point(360, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 21);
            this.label10.TabIndex = 69;
            this.label10.Text = "Email Address:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkCyan;
            this.label11.Location = new System.Drawing.Point(24, 409);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 21);
            this.label11.TabIndex = 70;
            this.label11.Text = "Shift hours";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkCyan;
            this.label7.Location = new System.Drawing.Point(24, 199);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 21);
            this.label7.TabIndex = 66;
            this.label7.Text = " Surname:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkCyan;
            this.label4.Location = new System.Drawing.Point(24, 266);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 21);
            this.label4.TabIndex = 62;
            this.label4.Text = "Date of birth:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DarkCyan;
            this.label16.Location = new System.Drawing.Point(24, 122);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 21);
            this.label16.TabIndex = 61;
            this.label16.Text = "Name:";
            // 
            // cmbEmployeeID
            // 
            this.cmbEmployeeID.FormattingEnabled = true;
            this.cmbEmployeeID.Location = new System.Drawing.Point(21, 92);
            this.cmbEmployeeID.Name = "cmbEmployeeID";
            this.cmbEmployeeID.Size = new System.Drawing.Size(297, 21);
            this.cmbEmployeeID.TabIndex = 5;
            this.cmbEmployeeID.SelectedIndexChanged += new System.EventHandler(this.comboID_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkCyan;
            this.label6.Location = new System.Drawing.Point(17, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 21);
            this.label6.TabIndex = 4;
            this.label6.Text = "Select employee ID:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // btnBAck
            // 
            this.btnBAck.BackColor = System.Drawing.Color.DarkCyan;
            this.btnBAck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBAck.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBAck.ForeColor = System.Drawing.Color.White;
            this.btnBAck.Location = new System.Drawing.Point(21, 506);
            this.btnBAck.Name = "btnBAck";
            this.btnBAck.Size = new System.Drawing.Size(297, 34);
            this.btnBAck.TabIndex = 3;
            this.btnBAck.Text = "Back to options";
            this.btnBAck.UseVisualStyleBackColor = false;
            this.btnBAck.Click += new System.EventHandler(this.btnBAck_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DarkCyan;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(21, 466);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(297, 34);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkCyan;
            this.label8.Location = new System.Drawing.Point(672, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 30);
            this.label8.TabIndex = 0;
            this.label8.Text = "x";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkCyan;
            this.label2.Location = new System.Drawing.Point(16, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 30);
            this.label2.TabIndex = 0;
            this.label2.Text = " ";
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panelLeft;
            this.bunifuDragControl1.Vertical = true;
            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.DarkCyan;
            this.panelLeft.Controls.Add(this.label1);
            this.panelLeft.Controls.Add(this.pictureBox1);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(321, 579);
            this.panelLeft.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(57, 278);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 36);
            this.label1.TabIndex = 3;
            this.label1.Text = "Edit employee";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(82, 147);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 25;
            this.bunifuElipse1.TargetControl = this;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(28, 291);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(297, 20);
            this.dateTimePicker1.TabIndex = 92;
            // 
            // Edit_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1117, 579);
            this.Controls.Add(this.panelRight);
            this.Controls.Add(this.panelLeft);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Edit_Employee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit_Employee";
            this.Load += new System.EventHandler(this.Edit_Employee_Load);
            this.panelRight.ResumeLayout(false);
            this.panelRight.PerformLayout();
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.ComboBox cmbEmployeeID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnBAck;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Panel panelLeft;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label15;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtZipCode;
        private System.Windows.Forms.Label label14;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSuburb;
        private System.Windows.Forms.Label label12;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtJobPosition;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label5;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtHouseNumber;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label16;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtShift;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtCellNumber;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtEmailAddress;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtStreetName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSurname;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}