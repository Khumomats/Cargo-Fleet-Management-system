﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Moving_Cargo
{
    public partial class Options : Form
    {
        public Options()
        {
            InitializeComponent();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {

            //Opens customer form
            this.Hide();
            Customer cm = new Customer();
            cm.ShowDialog();
        }

        private void btnDriver_Click(object sender, EventArgs e)
        {
            this.Hide();
            Driver d = new Driver();
            d.ShowDialog();
        }

        private void btnService_Click(object sender, EventArgs e)
        {
            this.Hide();
            Service d = new Service();
            d.ShowDialog();
        }

        private void btnTrip_Click(object sender, EventArgs e)
        {

            //Opens trip form
            this.Hide();
            Trip d = new Trip();
            d.ShowDialog();
        }

        private void btnOsers_Click(object sender, EventArgs e)
        {
            this.Hide();
            Orders od = new Orders();
            od.ShowDialog();
        }

        private void btnVehicle_Click(object sender, EventArgs e)
        {
            this.Hide();
            Vehicle v = new Vehicle();
            v.ShowDialog();
        }

        private void btnTimeSheet_Click(object sender, EventArgs e)
        {

            this.Hide();
            TimeSheet tm = new TimeSheet();
            tm.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            this.Hide();
            Employee emp = new Employee();
            emp.Show();
        }
    }
}
