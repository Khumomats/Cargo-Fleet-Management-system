﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Edit_Vehicle : Form
    {
        public Edit_Vehicle()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options op = new Options();
            op.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Edit_Vehicle_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Vehicle_Info";
                SqlCommand command = new SqlCommand(sql, connection);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cmbVehicleNumber.Items.Add(reader[0].ToString());
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
        }

        private void cmbVehicleNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Vehicle_Info";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (cmbVehicleNumber.Text.Equals(reader[0].ToString()))
                    {
                        check = true;
                        txtRegNumber.Text = reader[1].ToString();
                        txtVehicleType.Text = reader[2].ToString();
                        txtManufacturer.Text = reader[3].ToString();
                        txtEngineSize.Text = reader[4].ToString();
                        txtCurrentOdometer.Text = reader[5].ToString();
                        txtNextService.Text = reader[6].ToString();
                        txtNumberOfTrips.Text = reader[7].ToString();
                        txtAvaliableTrips.Text = reader[8].ToString();

                        break;
                    }


                }
                if (check == true)
                {

                    MessageBox.Show("You can start editing Vehicle details \n" + "For Registration Number: " + reader[1].ToString() + "\n" + "Vehicle Type: " + reader[2].ToString());

                }
                else if (check == false)
                {
                    MessageBox.Show("The Vehicle ID you chose doesn't match any in the database!!!! ");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occured: " + ex.Message);

            }
        }

        private void btnSaveVehicle_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "UPDATE Vehicle_Info SET  Reg_Num= '" + txtRegNumber.Text + "', Vehicle_Type= '" + txtVehicleType.Text + "', " +
                                                  "Manufacturer = '" + txtManufacturer.Text + "', Engine_Size = '" + txtEngineSize.Text + "', Current_Odometer = '" + txtCurrentOdometer.Text + "'," +
                                                  " Next_Service= '" + txtNextService.Text + "', Num_Trips = '" + txtNumberOfTrips.Text + "', Avail_Trips = '" + txtAvaliableTrips.Text + "'" +
                                                  "WHERE Vehicle_Num = '" + cmbVehicleNumber.Text + "'";
                SqlCommand command = new SqlCommand(sql, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Vehicle details successfully updated!!!:");

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
    }
}
