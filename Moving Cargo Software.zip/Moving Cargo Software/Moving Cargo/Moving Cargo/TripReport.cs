﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Moving_Cargo
{
    public partial class TripReport : Form
    {
        public TripReport()
        {
            InitializeComponent();
        }

        private void TripReport_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Booking_Trip";
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandText = sql;

                SqlDataAdapter reader = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                reader.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                connection.Close();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
    }
}
