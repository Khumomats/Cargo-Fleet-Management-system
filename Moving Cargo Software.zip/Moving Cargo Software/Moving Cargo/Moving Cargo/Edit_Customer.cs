﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Edit_Customer : Form
    {
        public Edit_Customer()
        {
            InitializeComponent();
        }

        private void btnBAck_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options op = new Options();
            op.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPhoneNumber.Text.Length < 10 || txtPhoneNumber.Text.Length > 10)
                {
                    MessageBox.Show("Phone Number should be 10 digits");
                }
                else
                {
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "UPDATE Customers SET Customer_Name = '" + txtName.Text + "', Customer_Surname = '" + txtSurname.Text + "', " +
                                                      "Customer_Cell_Num = '" + txtPhoneNumber.Text + "', Customer_Email = '" + txtEmail.Text + "', House_Num = '" + Convert.ToInt32(txtHouseNumber.Text) + "'," +
                                                      " Street_Name = '" + txtStreetName.Text + "', Suburb = '" + txtSuburb.Text + "', ZipCode = '" + txtZipCode.Text + "'" +
                                                      "WHERE Customer_ID = '" + cmbCustomerID.Text + "'";
                    SqlCommand command = new SqlCommand(sql, connection);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Customer details successfully updated!!!:");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void Edit_Customer_Load(object sender, EventArgs e)
        {
            try 
            {
                
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Customers";
                SqlCommand command = new SqlCommand(sql, connection);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cmbCustomerID.Items.Add(reader[0].ToString());
                }
            }
            catch(Exception ex)   
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
           
        }
        private void cmbCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try 
            {
                
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Customers";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (cmbCustomerID.Text.Equals(reader[0].ToString()))
                    {
                        check = true;
                        txtName.Text = reader[1].ToString();
                        txtSurname.Text = reader[2].ToString();
                        txtPhoneNumber.Text = reader[3].ToString();
                        txtEmail.Text = reader[4].ToString();
                        txtHouseNumber.Text = reader[5].ToString();
                        txtStreetName.Text = reader[6].ToString();
                        txtSuburb.Text = reader[7].ToString();
                        txtZipCode.Text = reader[8].ToString();
                        break;
                    }
                    
                    
                }
                if (check == true)
                {

                    MessageBox.Show("You can start editing Customer details \n" + 
                                    "For Name: " + reader[1].ToString() + "\n" + 
                                    "Surname: " + reader[2].ToString() );
                    
                }
                else if (check == false)
                {
                    MessageBox.Show("The Customer ID you chose doesn't match any in the database!!!! ");
                }
                
            } 
            catch (Exception ex) 
            {
                MessageBox.Show("An error has occured: " + ex.Message);

            }
        }


        private void panelRight_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelLeft_Paint(object sender, PaintEventArgs e)
        {

        }

       
    }
}
