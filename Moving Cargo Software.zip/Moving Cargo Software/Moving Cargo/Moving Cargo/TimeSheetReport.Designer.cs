﻿
namespace Moving_Cargo
{
    partial class TimeSheetReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.movingCargoDatabaseDataSet = new Moving_Cargo.MovingCargoDatabaseDataSet();
            this.movingCargoDatabaseDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.movingCargoDatabaseDataSet1 = new Moving_Cargo.MovingCargoDatabaseDataSet1();
            this.movingCargoDatabaseDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnBack = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // movingCargoDatabaseDataSet
            // 
            this.movingCargoDatabaseDataSet.DataSetName = "MovingCargoDatabaseDataSet";
            this.movingCargoDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // movingCargoDatabaseDataSetBindingSource
            // 
            this.movingCargoDatabaseDataSetBindingSource.DataSource = this.movingCargoDatabaseDataSet;
            this.movingCargoDatabaseDataSetBindingSource.Position = 0;
            // 
            // movingCargoDatabaseDataSet1
            // 
            this.movingCargoDatabaseDataSet1.DataSetName = "MovingCargoDatabaseDataSet1";
            this.movingCargoDatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // movingCargoDatabaseDataSet1BindingSource
            // 
            this.movingCargoDatabaseDataSet1BindingSource.DataSource = this.movingCargoDatabaseDataSet1;
            this.movingCargoDatabaseDataSet1BindingSource.Position = 0;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(33, 326);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(33, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(743, 248);
            this.dataGridView1.TabIndex = 2;
            // 
            // TimeSheetReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnBack);
            this.Name = "TimeSheetReport";
            this.Text = "TimeSheetReport";
            this.Load += new System.EventHandler(this.TimeSheetReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingCargoDatabaseDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource movingCargoDatabaseDataSet1BindingSource;
        private MovingCargoDatabaseDataSet1 movingCargoDatabaseDataSet1;
        private MovingCargoDatabaseDataSet movingCargoDatabaseDataSet;
        private System.Windows.Forms.BindingSource movingCargoDatabaseDataSetBindingSource;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}