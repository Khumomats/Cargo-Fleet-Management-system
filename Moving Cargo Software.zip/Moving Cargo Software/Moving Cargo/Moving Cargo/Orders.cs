﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class Orders : Form
    {
        int number = 0;
        public Orders()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Edit_Order eo = new Edit_Order();
            eo.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Options p = new Options();
            p.ShowDialog();
        }

        private void btnSaveOrder_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "INSERT INTO Trips" +
                             "(" +
                             "Trip_Num, Employee_ID, Vehicle_Num, Customer_ID, Driver_Num, Trip_Schedule, Distance, Trip_Status" +
                             ") " +
                             "VALUES('" + txtTripNumber.Text + "','" + cmbEmpID.Text + "','" + cmbVehicleNumber.Text + "','" +cmbCustomerID.Text + "',' " + cmbDriverNumber.Text + "','" + dateTimePicker1.Value + "','" + txtDistance.Text + "','" + txtTripStatus.Text + "')";
                SqlCommand command = new SqlCommand(sql, connection);

                command.ExecuteNonQuery();
                MessageBox.Show("Orders details successfully saved");
                connection.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void Orders_Load(object sender, EventArgs e)
        {
           
                try
                {
                GetCustomerID();
                GetVehicleNumber();
                GetEmployeeID();
                    SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                    connection.Open();
                    string sql = "SELECT * FROM Driver";
                    SqlCommand command = new SqlCommand(sql, connection);

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbDriverNumber.Items.Add(reader[0].ToString());
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show("An error occurred:" + ex.Message);
                }
            
        }

       
        private int GetVehicleNumber()
        {


            try
            {
               

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Vehicle_Info";
                SqlCommand command = new SqlCommand(sql, connection);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    number = cmbVehicleNumber.Items.Add(reader[0].ToString());

                }
                return number;
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
            return number;
        }
        private int GetEmployeeID()
        {


            try
            {


                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Employee";
                SqlCommand command = new SqlCommand(sql, connection);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    number = cmbEmpID.Items.Add(reader[0].ToString());

                }
                return number;
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
            return number;
        }
        private int GetCustomerID()
        {


            try
            {


                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Customers";
                SqlCommand command = new SqlCommand(sql, connection);

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    number = cmbCustomerID.Items.Add(reader[0].ToString());

                }
                return number;
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
            return number;
        }

        private void cmbCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbVehicleNumber_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void cmbDriverNumber_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
