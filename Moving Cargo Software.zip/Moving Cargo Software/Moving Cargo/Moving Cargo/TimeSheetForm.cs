﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Moving_Cargo
{
    public partial class TimeSheetForm : Form
    {
        public TimeSheetForm()
        {
            InitializeComponent();
        }

        private void TimeSheetForm_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Employee";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    check = true;
                    comboBox1.Items.Add(reader[0].ToString());
                    break;
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred:" + ex.Message);
            }
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "INSERT INTO TimeSheet" +
                             "(" +
                             " Employee_ID, Hours_Worked, Time_In, Time_Out " +
                             ") " +
                             "VALUES('" + comboBox1.Text + "','" + txtHours.Text + "','" + txtTimeIn.Text + "','" + txtTimeOut.Text +"')";
                SqlCommand command = new SqlCommand(sql, connection);

                command.ExecuteNonQuery();
                MessageBox.Show("Orders details successfully saved");
                connection.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-6HBTE5E5\SQLEXPRESS;Initial Catalog=MovingCargoDatabase;Integrated Security=True");
                connection.Open();
                string sql = "SELECT * FROM Employee";
                SqlCommand command = new SqlCommand(sql, connection);
                bool check = false;
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    if (comboBox1.Text.Equals(reader[0].ToString()))
                    {
                        check = true;
                       
                        break;
                    }


                }
                if (check == true)
                {
                    MessageBox.Show("You can start editing Employee details \n" +
                                    " For Name : " + reader[1].ToString() + "\n" +
                                    " Surname: " + reader[2].ToString());
                }
                else if (check == false)
                {
                    MessageBox.Show("The Employee ID you chose doesn't match any in the database!!!! ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error has occured: " + ex.Message);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            TimeSheetReport r = new TimeSheetReport();
            r.Show();
        }
        
    }
}
